package org.example;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ProblemTest {

    @Test
    public void testGenerateItems() {
        Problem problem = new Problem(10, 1234, 1, 10, 50);
        List<Item> items = problem.getItems();
        assertEquals(10, items.size());
        for (Item item : items) {
            assertTrue(item.getWeight() >= 1 && item.getWeight() <= 10);
            assertTrue(item.getValue() >= 1 && item.getValue() <= 10);
        }
    }

    @Test
    public void testSolveWithItemsThatFit() {
        Problem problem = new Problem(10, 1234, 1, 10, 50);
        Result result = problem.solve();
        assertTrue(result.getTotalWeight() <= 50);
        assertTrue(result.getTotalValue() > 0);
    }

    @Test
    public void testSolveWithNoItemsThatFit() {
        Problem problem = new Problem(10, 1234, 20, 30, 5);
        Result result = problem.solve();
        assertEquals(0, result.getTotalWeight());
        assertEquals(0, result.getTotalValue());
    }

    @Test
    public void testSolveSpecificInstance() {
        Problem problem = new Problem(3, 1, 1, 2, 5);
        List<Item> items = problem.getItems();
        items.clear();
        items.add(new Item(10, 1));
        items.add(new Item(20, 2));
        items.add(new Item(30, 3));
        Result result = problem.solve();

        assertEquals(5, result.getTotalWeight());
        assertEquals(50, result.getTotalValue());
    }
}