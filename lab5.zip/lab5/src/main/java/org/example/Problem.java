package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Problem {
    private List<Item> items;
    private int capacity;

    public Problem(int n, int seed, int lowerBound, int upperBound, int capacity) {
        this.capacity = capacity;
        items = new ArrayList<>();
        Random random = new Random(seed);

        for (int i = 0; i < n; i++) {
            int value = lowerBound + random.nextInt(upperBound - lowerBound + 1);
            int weight = lowerBound + random.nextInt(upperBound - lowerBound + 1);
            items.add(new Item(value, weight));
        }
    }

    public List<Item> getItems() {
        return items;
    }

    public int getCapacity() {
        return capacity;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            sb.append("No: ").append(i).append(" ").append(items.get(i)).append("\n");
        }
        return sb.toString();
    }

    public Result solve() {
        items.sort((a, b) -> Double.compare((double) b.getValue() / b.getWeight(), (double) a.getValue() / a.getWeight()));

        List<Item> selectedItems = new ArrayList<>();
        int totalValue = 0;
        int totalWeight = 0;

        for (Item item : items) {
            while (totalWeight + item.getWeight() <= capacity) {
                selectedItems.add(item);
                totalWeight += item.getWeight();
                totalValue += item.getValue();
            }
        }

        return new Result(selectedItems, totalValue, totalWeight);
    }
}
